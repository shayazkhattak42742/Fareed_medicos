FAREED MEDICOS — ANDROID APP PROJECT

This is a native Android wrapper project for the offline Fareed Medicos inventory, billing, expiry alerts, profit reports, and backup app. The app's screens run locally and do not require internet access. Records are saved on the device in the app's browser storage.

IMPORTANT: This ZIP is the Android Studio source project, not a precompiled APK. An Android SDK/Gradle build environment is needed to compile the installable APK.

HOW TO BUILD AN APK:
1. Install Android Studio on a computer and allow it to install Android SDK Platform 35 and the required Gradle components.
2. Extract this ZIP.
3. In Android Studio choose Open, then select the extracted FareedMedicosAndroid folder.
4. Wait for Gradle sync to finish.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. For the debug APK, Android Studio will show a link to the APK, usually app/build/outputs/apk/debug/app-debug.apk.
7. Transfer that APK to your Android phone and open it to install. You may need to allow installation from that file manager.

DATA SAFETY:
- Records are stored locally on this phone; uninstalling the app or clearing app data can erase them.
- Use Reports > Export backup regularly. Keep the backup file somewhere safe.
- This is an inventory and sales record tool, not a clinical decision-support system. Verify medicine, batch, expiry, and prices yourself.
